import { Hero } from './hero';

export const HEROES: Hero[] = [
  { id: 11, name: 'KEERTHANA' },
  { id: 12, name: 'PRIYA' },
  { id: 13, name: 'THARUN' },
  { id: 14, name: 'GAUSHIK' },
  { id: 15, name: 'DIVYA' },
  { id: 16, name: 'PALLAVI' },
  { id: 17, name: 'JANA' },
  { id: 18, name: 'GIRIJA' },
  { id: 19, name: 'ADEENA' },
  { id: 20, name: 'DEEPA' }
];
